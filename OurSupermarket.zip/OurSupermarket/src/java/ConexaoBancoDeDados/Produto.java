/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ConexaoBancoDeDados;

import java.sql.*;
import ClassesJava.ProdutoDAO;

public class Produto {
    private Connection conBanco;
    private PreparedStatement psComando;
    private PreparedStatement stmt;
    private ResultSet rsRegistros;
    
    public void configurarConexao(Connection conBanco) {this.conBanco = conBanco;}
    
    public boolean inserirRegistro(ProdutoDAO p){
        String strComandoSQL;
        try{
            strComandoSQL = "INSERT INTO produto (nome,fornecedor,preco,estoque) VALUES (?,?,?,?)";
            stmt = conBanco.prepareStatement(strComandoSQL);
            stmt.setString(1,p.getNome());
            stmt.setInt(2,p.getFornecedor());
            stmt.setFloat(3,p.getPreco());
            stmt.setInt(4,p.getEstoque());
            stmt.execute();
            
            return true;
        }catch(Exception erro){
            erro.printStackTrace();
            return false;
        }
    }
    
    public boolean alterarRegistro(String id, String nome, int fornecedor, float preco, int estoque){
        String strComandoSQL;
        try{
            //int idNovo = Integer.parseInt(id);
            strComandoSQL = "UPDATE produto SET nome=?,fornecedor=?,preco=?,estoque=? WHERE id="+id;
            stmt = conBanco.prepareStatement(strComandoSQL);
            stmt.setString(1,nome);
            stmt.setInt(2,fornecedor);
            stmt.setFloat(3,preco);
            stmt.setInt(4,estoque);
            stmt.executeUpdate();
            
            return true;
        }catch(Exception erro){
            erro.printStackTrace();
            return false;
        }
    }
    
    public boolean excluirRegistro(int id){
        String strComandoSQL;
        try{
            strComandoSQL = "DELETE FROM produto WHERE id = "+id;
            psComando = conBanco.prepareStatement(strComandoSQL);
            psComando.executeUpdate();
            
            return true;
        }catch(Exception erro){
            erro.printStackTrace();
            return false;
        }
    }
    
    public ResultSet ListarRegistro(int ordem){
        String strComandoSQL;
        try{
            if(ordem == 0){
                strComandoSQL = "SELECT * FROM oursupermarket.produto WHERE id";
            }else{
                strComandoSQL = "SELECT * FROM oursupermarket.produto WHERE id="+ordem;
            }
             
            
            psComando = conBanco.prepareStatement(strComandoSQL);
            rsRegistros = psComando.executeQuery();
            
            return rsRegistros;
        }catch(Exception erro){
            erro.printStackTrace();
            return null;
        }
    }
    
    public boolean alterarEstoque(int id, String nome, int fornecedor, float preco, int estoque){
        String strComandoSQL;
        try{
            //int idNovo = Integer.parseInt(id);
            strComandoSQL = "UPDATE produto SET nome=?,fornecedor=?,preco=?,estoque=? WHERE id="+id;
            stmt = conBanco.prepareStatement(strComandoSQL);
            stmt.setString(1,nome);
            stmt.setInt(2,fornecedor);
            stmt.setFloat(3,preco);
            stmt.setInt(4,estoque);
            stmt.executeUpdate();
            
            return true;
        }catch(Exception erro){
            erro.printStackTrace();
            return false;
        }
    }
}
