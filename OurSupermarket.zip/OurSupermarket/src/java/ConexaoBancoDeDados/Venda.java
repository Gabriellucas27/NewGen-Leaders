/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ConexaoBancoDeDados;

import java.sql.*;

public class Venda {
    private Connection conBanco;
    private PreparedStatement psComando;
    private PreparedStatement stmt;
    private ResultSet rsRegistros;
    
    public void configurarConexao(Connection conBanco) {this.conBanco = conBanco;}
    
    public boolean inserirRegistro(int produto, int cliente, String dataVenda){
        String strComandoSQL;
        try{
            strComandoSQL = "INSERT INTO venda (produto,cliente,dataVenda) VALUES (?,?,?)";
            stmt = conBanco.prepareStatement(strComandoSQL);
            stmt.setInt(1,produto);
            stmt.setInt(2,cliente);
            stmt.setString(3,dataVenda);
            stmt.execute();
            
            return true;
        }catch(Exception erro){
            erro.printStackTrace();
            return false;
        }
    }
    
    public boolean alterarRegistro(String id, int produto, int cliente, String dataVenda){
        String strComandoSQL;
        try{
            //int idNovo = Integer.parseInt(id);
            strComandoSQL = "UPDATE venda SET produto=?,cliente=?,dataVenda=? WHERE id="+id;
            stmt = conBanco.prepareStatement(strComandoSQL);
            stmt.setInt(1,produto);
            stmt.setInt(2,cliente);
            stmt.setString(3,dataVenda);
            stmt.executeUpdate();
            
            return true;
        }catch(Exception erro){
            erro.printStackTrace();
            return false;
        }
    }
    
    public boolean excluirRegistro(int id){
        String strComandoSQL;
        try{
            strComandoSQL = "DELETE FROM venda WHERE id = "+id;
            psComando = conBanco.prepareStatement(strComandoSQL);
            psComando.executeUpdate();
            
            return true;
        }catch(Exception erro){
            erro.printStackTrace();
            return false;
        }
    }
    
    public ResultSet ListarRegistro(int ordem){
        String strComandoSQL;
        try{
            if(ordem == 0){
                strComandoSQL = "SELECT * FROM oursupermarket.venda WHERE id";
            }else{
                strComandoSQL = "SELECT * FROM oursupermarket.venda WHERE id="+ordem;
            }
             
            
            psComando = conBanco.prepareStatement(strComandoSQL);
            rsRegistros = psComando.executeQuery();
            
            return rsRegistros;
        }catch(Exception erro){
            erro.printStackTrace();
            return null;
        }
    }
}
