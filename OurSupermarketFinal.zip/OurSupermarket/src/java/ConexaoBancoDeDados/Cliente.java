/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ConexaoBancoDeDados;

import java.sql.*;
import ClassesJava.ClienteDAO;

public class Cliente {
    private Connection conBanco;
    private PreparedStatement psComando;
    private PreparedStatement stmt;
    private ResultSet rsRegistros;
    
    public void configurarConexao(Connection conBanco) {this.conBanco = conBanco;}
    
    public boolean inserirRegistro(ClienteDAO c){
        String strComandoSQL;
        try{
            strComandoSQL = "INSERT INTO cliente (nome,telefone,cpf,rg,email,endereco) VALUES (?,?,?,?,?,?)";
            stmt = conBanco.prepareStatement(strComandoSQL);
            stmt.setString(1,c.getNome());
            stmt.setString(2,c.getTelefone());
            stmt.setString(3,c.getCpf());
            stmt.setString(4,c.getRg());
            stmt.setString(5,c.getEmail());
            stmt.setInt(6,c.getEndereco());
            stmt.execute();
            
            return true;
        }catch(Exception erro){
            erro.printStackTrace();
            return false;
        }
    }
    
    public boolean alterarRegistro(String id, String nome, String telefone, String cpf, String rg, String email, int endereco){
        String strComandoSQL;
        try{
            //int idNovo = Integer.parseInt(id);
            strComandoSQL = "UPDATE cliente SET nome=?,telefone=?,cpf=?,rg=?,email=?,endereco=? WHERE id="+id;
            stmt = conBanco.prepareStatement(strComandoSQL);
            stmt.setString(1,nome);
            stmt.setString(2,telefone);
            stmt.setString(3,cpf);
            stmt.setString(4,rg);
            stmt.setString(5,email);
            stmt.setInt(6,endereco);
            stmt.executeUpdate();
            
            return true;
        }catch(Exception erro){
            erro.printStackTrace();
            return false;
        }
    }
    
    public boolean excluirRegistro(int id){
        String strComandoSQL;
        try{
            strComandoSQL = "DELETE FROM cliente WHERE id = "+id;
            psComando = conBanco.prepareStatement(strComandoSQL);
            psComando.executeUpdate();
            
            return true;
        }catch(Exception erro){
            erro.printStackTrace();
            return false;
        }
    }
    
    public ResultSet ListarRegistro(int ordem){
        String strComandoSQL;
        try{
            if(ordem == 0){
                strComandoSQL = "SELECT * FROM oursupermarket.cliente WHERE id";
            }else{
                strComandoSQL = "SELECT * FROM oursupermarket.cliente WHERE id="+ordem;
            }
             
            
            psComando = conBanco.prepareStatement(strComandoSQL);
            rsRegistros = psComando.executeQuery();
            
            return rsRegistros;
        }catch(Exception erro){
            erro.printStackTrace();
            return null;
        }
    }
}
