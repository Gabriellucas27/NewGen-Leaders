/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ConexaoBancoDeDados;

import java.sql.*;
import ClassesJava.FornecedorDAO;

public class Fornecedor {
    private Connection conBanco;
    private PreparedStatement psComando;
    private PreparedStatement stmt;
    private ResultSet rsRegistros;
    
    public void configurarConexao(Connection conBanco) {this.conBanco = conBanco;}
    
    public boolean inserirRegistro(FornecedorDAO f){
        String strComandoSQL;
        try{
            strComandoSQL = "INSERT INTO fornecedor (nome,telefone,cnpj,endereco) VALUES (?,?,?,?)";
            stmt = conBanco.prepareStatement(strComandoSQL);
            stmt.setString(1,f.getNome());
            stmt.setString(2,f.getTelefone());
            stmt.setString(3,f.getCnpj());
            stmt.setInt(4,f.getEndereco());
            stmt.execute();
            
            return true;
        }catch(Exception erro){
            erro.printStackTrace();
            return false;
        }
    }
    
    public boolean alterarRegistro(String id, String nome, String telefone, String cnpj, int endereco){
        String strComandoSQL;
        try{
            //int idNovo = Integer.parseInt(id);
            strComandoSQL = "UPDATE fornecedor SET nome=?,telefone=?,cnpj=?,endereco=? WHERE id="+id;
            stmt = conBanco.prepareStatement(strComandoSQL);
            stmt.setString(1,nome);
            stmt.setString(2,telefone);
            stmt.setString(3,cnpj);
            stmt.setInt(4,endereco);
            stmt.executeUpdate();
            
            return true;
        }catch(Exception erro){
            erro.printStackTrace();
            return false;
        }
    }
    
    public boolean excluirRegistro(String id){
        String strComandoSQL;
        try{
            strComandoSQL = "DELETE FROM fornecedor WHERE id = "+id;
            psComando = conBanco.prepareStatement(strComandoSQL);
            psComando.executeUpdate();
            
            return true;
        }catch(Exception erro){
            erro.printStackTrace();
            return false;
        }
    }
    
    public ResultSet ListarRegistro(int ordem){
        String strComandoSQL;
        try{
            if(ordem == 0){
                strComandoSQL = "SELECT * FROM oursupermarket.fornecedor WHERE id";
            }else{
                strComandoSQL = "SELECT * FROM oursupermarket.fornecedor WHERE id="+ordem;
            }
             
            
            psComando = conBanco.prepareStatement(strComandoSQL);
            rsRegistros = psComando.executeQuery();
            
            return rsRegistros;
        }catch(Exception erro){
            erro.printStackTrace();
            return null;
        }
    }
}
